﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectLab
{
    class FileManager
    {
        string[] arrLine;
        string data;
        string path = @"C:\Users\Legion\source\repos\ProjectLab\ProjectLab\";
        public FileManager(string text)
        {
            path = path + text + ".txt";
        }

        public FileManager()
        {
           
        }
        public string[] DeleteThisWord(string word, string[] mass)
        {
            for (int q = 0; q < mass.Length; q++)
            {
                if (mass[q] == word)
                {
                    mass[q] = null;
                    mass = mass.Where(x => !string.IsNullOrWhiteSpace(x)).ToArray();
                }
            }
            return mass;
        }

        public string[] GetTextFileAsyncArr()
        {
            GetTextFileAsync();
            return arrLine;
        }

        public string GetTextFileAsyncVar()
        {
            GetTextFileAsyncVarIntro();
            return data;
        }

        public async void GetTextFileAsync()
        {
            string line;
            string data = "";
            using (StreamReader sr = new StreamReader(path))
            {
                while ((line = sr.ReadLine()) != null)
                {
                    data += line;
                }
            }

            arrLine = DeleteThisWord("", data.ToString().Split(';'));

        }

        async void GetTextFileAsyncVarIntro()
        {
            string path = @"C:\Users\Legion\source\repos\ProjectLab\ProjectLab\Users.txt";

            using (StreamReader sr = new StreamReader(path))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    data += line;
                }
                Console.WriteLine(data.ToString());
            }
        }

        public void ArrayToFile(string[] arrLine)
        {
            using (StreamWriter sw = new StreamWriter(path))
            {
                for (int i = 0; i < arrLine.Length; i++)
                {
                    sw.Write(arrLine[i] + ";");
                }

            }
        }
    }
}


















//Muratov