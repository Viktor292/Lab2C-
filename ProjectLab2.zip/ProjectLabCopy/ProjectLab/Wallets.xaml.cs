﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjectLab
{
    public partial class Wallets : Window
    {

        static string path = @"C:\Users\Legion\source\repos\ProjectLab\ProjectLab\";
        string[] arrLine;
        FileManager fm;
        public Wallets(string text)
        {
            path = path + text + ".txt";
            InitializeComponent();
            fm = new FileManager(text);
            arrLine = fm.GetTextFileAsyncArr();
            for (int i = 0; i < arrLine.Length; i++)
            {
                WalletList.Items.Insert(1, arrLine[i]);
            }
        }

        private bool NamePresent(string name)
        {
            for(int i = 0; i < arrLine.Length; i++)
            {
                Console.WriteLine(name);
                Console.WriteLine(arrLine[i].Split(' ')[0]);
                if(arrLine[i].Split(' ')[0].Equals(name)) return true;
            }
            return false;
        }

        private int NameIndex(string name)
        {
            for (int i = 0; i < arrLine.Length; i++)
            {
                if (arrLine[i].Split(' ')[0].Equals(name)) return i;
            }
            return -1;
        }

        private void AddClick(object sender, RoutedEventArgs e)
        {
            try
            {
                Console.WriteLine(NameBox.Text.Split(' ')[0]);
                if (NamePresent(NameBox.Text) == true)
                {
                    AddButton.Background = Brushes.Red;
                    return;
                }
                string moneytype = "";
                if (EURBox.IsChecked == true) moneytype = "EUR";
                else moneytype = "USD";
                WalletList.Items.Insert(1, NameBox.Text + " " + DescrBox.Text + " " + "0" + " " + moneytype);
                Array.Resize(ref arrLine, arrLine.Length + 1);
                arrLine[arrLine.Length - 1] = NameBox.Text + " " + DescrBox.Text + " " + "0" + " " + moneytype;
                fm.ArrayToFile(arrLine);
                AddButton.Background = Brushes.Green;
            }
            catch (Exception exc)
            {
                AddButton.Background = Brushes.Red;
            }
        }


        private void EditClick(object sender, RoutedEventArgs e)
        {
            try
            {
                if (NamePresent(NameBox.Text) == true)
                {
                    EditButton.Background = Brushes.Red;
                    return;
                }
                string moneytype = "";
                if (EURBox.IsChecked == true) moneytype = "EUR";
                else moneytype = "USD";

            Console.WriteLine("Index selected " + WalletList.SelectedIndex);
            Console.WriteLine("Length selected " + arrLine.Length);
            arrLine[WalletList.SelectedIndex - 1] = NameBox.Text + " " + DescrBox.Text + " " + "0" + " " + moneytype;
            WalletList.Items.Remove(WalletList.SelectedItem);
            WalletList.Items.Insert(1, NameBox.Text + " " + DescrBox.Text + " " + "0" + " " + moneytype);
            fm.ArrayToFile(arrLine);
                EditButton.Background = Brushes.Green;
            }
            catch (Exception exc)
            {
               EditButton.Background = Brushes.Red;
            }
        }

        private void RemoveClick(object sender, RoutedEventArgs e)
        {
            if (WalletList.SelectedIndex == -1)
            {
                RemoveButton.Background = Brushes.Red;
                return;
            }
            try
            {
                Console.WriteLine(WalletList.SelectedIndex);
                Console.WriteLine(arrLine.Length);
                var list = arrLine.ToList();
                list.Remove(WalletList.SelectedItem.ToString());
                arrLine = list.ToArray();
                WalletList.Items.Remove(WalletList.SelectedItem);
                fm.ArrayToFile(arrLine);
                RemoveButton.Background = Brushes.Green;
            }
            catch (Exception exc)
            {
                RemoveButton.Background = Brushes.Red;
            }
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {

        }
    }
}








//Muratov